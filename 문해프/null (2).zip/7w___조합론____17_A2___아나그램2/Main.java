import java.util.*;

class Main {
	
	public static String[] anaResult = new String[50000];
	public static int index = 0;
	public static int numForP = 0;
	
	public static void rememNum(int num) {
		numForP = num;
	}
	public static int getRemNum() {
		return numForP;
	}
	public static void clearNum() {
		numForP = 0;
	}

	public static void set(int[] lett, int[] temp, int[] check, int index, int n, int r) {
        if(index == r) {
        	putArray(temp, r);
            return;
        }
        for(int i=0; i<n; i++) {
            if(check[i] == 0) {
                check[i] = 1;
                temp[index] = lett[i];
                set(lett, temp, check, index+1, n, r);       
                temp[index] = 0; // 이 줄은 없어도 됨
                check[i] = 0;;
            }
        }
    }
	
	public static void putArray(int[] lett, int r) {
		String anaCom = "";
        for(int i=0; i<r; i++){
        	//System.out.print(Character.toString((char) arr[i]));
            anaCom += Character.toString((char) lett[i]);
        }
       // System.out.println();
        if(index == 0) {	// anaResult 배열에 아무것도 없으면 일단 넣고 보자
        	anaResult[index] = anaCom;
        	index++;
        }
        else {	//배열에 뭔가 있으면 지금 들어갈 String과 전에 있던 친구들을 비교해서 같으면 넣지말고 다르면 넣자
        	int check = 0;
        	for(int i=0; i<index; i++) {
        		if(anaCom.equalsIgnoreCase(anaResult[i])) 
        			check++;
        	}
        	if(check == 0){
        		anaResult[index] = anaCom;
            	index++;
        	}
        	/*else
        		System.out.println("중복 찾아냄");
        	*/
        }
    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		for(int i=0; i<anaResult.length; i++)
			anaResult[i] = null;
		index = 0;
		clearNum();
		while (input.hasNext()) {
			String line = input.nextLine();
			//새로운 라인을 읽을 때 마다 아나그램을 저장하는 배열을 초기화해주어야한다. index도 초기화해주야됨
			for(int i=0; i<anaResult.length; i++)
				anaResult[i] = null;
			index = 0;
			if (line.equals("*"))
				break; // 입력의 끝이 *이라고 함

			String parse[] = line.split(":");
			String word = parse[0];
			int num = Integer.parseInt(parse[1]);
			rememNum(num);
			// 입력에 대한 처리 완료

			int[] lett = new int[word.length()];
			for (int i = 0; i < lett.length; i++) {
				lett[i] = word.charAt(i);
			} // 단어를 글자대로 쪼개넣음
			Arrays.sort(lett);
			// System.out.println(letays.toString(let));
			int len = lett.length;
			int[] temp = new int[len];
			int[] check = new int[len];
			 
	        set(lett, temp, check, 0, len, len);
	        /*
	        System.out.println("anaResult has real value?");
	        for(int i=0; i<anaResult.length; i++)
	        	System.out.println(anaResult[i]);
	        */
	        
	        // anaResult배열에서 중복되는 원소가 있는지 확인하고 제거해야한다.
	        // 이미 정렬된 상태로 입력되어있기 때문에 주변에 있는 원소끼리만 비교하면 된다
	       /* System.out.println("전체 아나그램 출력");
	        for(int i=0; i<index; i++) {
	        	System.out.println(anaResult[i]);
	        }*/
	        //System.out.println("원하는 num에 맞는 아나그램 출력");
	        System.out.println(anaResult[getRemNum()-1]);
		}
		//System.out.println("*이 제대로 실행되는가?");
		//System.out.println(anaResult[getRemNum()-1]);
	}

}
