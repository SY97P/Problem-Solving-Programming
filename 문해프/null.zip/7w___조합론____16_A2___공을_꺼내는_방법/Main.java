import java.io.*;
import java.util.*;

class Main {

	public static void main(String[] args) {
		// TODO 자동 생성된 메소드 스텁

		Scanner input = new Scanner(System.in);
		
		while(input.hasNext()) {
			String line = input.nextLine();
			String parse[] = line.split(" ");
			
			int n = Integer.parseInt(parse[0]);
			int k = Integer.parseInt(parse[1]);
			
			int[] f = new int[n];
			
			for(int i=0; i<n; i++) {
				if(i == 0) 
					f[i] = 1;
				else if(i<k) {
					int sum = 1;
					for(int j=i-1; j>=0; j--) {
						sum += f[j];
					}
					f[i] = sum;
				} else if(i>=k) {
					int sum = 0;
					for(int j=i-k; j<i; j++) {
						sum += f[j];
					}
					f[i] = sum;
				}
			}
			System.out.println(f[n-1]);
		}
	}

}
