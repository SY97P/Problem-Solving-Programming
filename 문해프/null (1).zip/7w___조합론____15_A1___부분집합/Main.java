
import java.util.*;

class Main {

	public static void set(int[] num, int[] arr, int len, int r, int index, int target) {
		if(r==0) 
			printSet(num, arr, index);
		else if(target == len) 
			return;	// 값에 대한 정보를 가지고 있는 숫자가 원래 길이를 넘었으니 잘못됨 -> 나가자
		else {
			arr[index] = target;
			//지금 뭘 넣었는지에 대한 인덱스를 조합 배열에 저장
			set(num, arr, len, r-1, index+1, target+1);
			set(num, arr, len, r, index, target+1);
		}
	}
	
	//입출력
	public static void printSet(int[] num, int[] arr, int index) {
		System.out.print("{ ");
		for(int i=0; i<index; i++) 
			System.out.print(num[arr[i]]+" ");
		System.out.println("}");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);

		String line = input.nextLine();
		String numSt[] = line.split(" ");
		int num[] = new int[numSt.length];
		int len = num.length;
		for (int i = 0; i < numSt.length; i++)
			num[i] = Integer.parseInt(numSt[i]);
		Arrays.sort(num);
		
		//원본배열의 원소를 넣기위한 배열 (target으로 작동)
		int arr[] = new int[len];

		for(int i=0; i<=len; i++) {
			set(num, arr, len, i, 0, 0);
		}
	}
}
