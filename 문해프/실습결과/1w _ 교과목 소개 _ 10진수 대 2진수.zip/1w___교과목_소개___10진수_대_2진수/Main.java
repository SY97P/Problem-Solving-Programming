/* Solution for week 1 problem 2 */

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

				while(input.hasNextLine()) {
					String line = input.nextLine();
					if(line.charAt(1) == 'x') {
						String decOrig = line.substring(2);
						int dec = Integer.parseInt(decOrig, 16);
						System.out.println(dec);
					} else {
						int oct = Integer.parseInt(line, 10);
						String octOut = Integer.toHexString(oct);
						System.out.println("0x"+octOut.toUpperCase());
					}
				}
    }
}
