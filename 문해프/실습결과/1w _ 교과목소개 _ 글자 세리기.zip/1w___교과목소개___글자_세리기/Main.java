import java.util.Scanner;
class Main {
	public static void main(String[] args) throws Exception {
		Scanner input = new Scanner(System.in);
		
		while(input.hasNextLine()) {
			String line = input.nextLine();
			line = line.trim();									//앞 뒤 공백 자르기
			int wordNum = 1;
			int letters = 0;
			for(int i=0; i<line.length(); i++) {
				if(line.charAt(i) == ' ') {
					if(line.charAt(i+1) != ' ')
						wordNum++;
				} else
					letters++;
			}
			System.out.println(wordNum+" "+letters);
		}
	}
}