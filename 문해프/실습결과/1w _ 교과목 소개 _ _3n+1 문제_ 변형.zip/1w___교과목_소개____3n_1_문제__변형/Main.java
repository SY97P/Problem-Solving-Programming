import java.util.Scanner;
class Main {
	public static void main(String[] args) throws Exception {
		Scanner input = new Scanner(System.in);
		
		while(input.hasNextInt()) {
			int num = input.nextInt();
			int check = input.nextInt();
			int count = 0;
			
			if(num == check) 
				System.out.println("Y");
			else {
				int j = num;
				while(j != 1) {
					if(j%2 == 1)
						j = j*3+1;
					else
						j = j/2;
					if(j == check) {
						System.out.println("Y");
						count++;
					}
				}
				if(count<1)
					System.out.println("N");
			}
		}
	}
}